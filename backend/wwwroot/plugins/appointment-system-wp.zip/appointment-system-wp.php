<?php
/**
 * Plugin Name: Appointment Booking Widget
 * Description: Embed your Booking SaaS form with a simple shortcode or editor button.
 * Version: 1.1
 * Author: Appointment System
 */

if (!defined('ABSPATH')) {
    exit;
}

// 1. Settings Menu to save Company Slug
function as_register_settings() {
    register_setting('as_widget_options', 'as_company_slug');
    add_options_page(
        'Appointment Widget', 
        'Appointment Widget', 
        'manage_options', 
        'as-widget-settings', 
        'as_render_settings_page'
    );
}
add_action('admin_menu', 'as_register_settings');

function as_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>Appointment Widget Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('as_widget_options'); ?>
            <?php do_settings_sections('as_widget_options'); ?>
            <table class="form-table">
                <tr valign="top">
                <th scope="row">Company Slug</th>
                <td>
                    <input type="text" name="as_company_slug" value="<?php echo esc_attr(get_option('as_company_slug')); ?>" class="regular-text" />
                    <p class="description">Enter your unique company slug from the SaaS dashboard.</p>
                </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// 2. "Add Booking Form" Button in Editor (Classic)
function as_add_media_button() {
    echo '<a href="#" id="insert-appointment-shortcode" class="button"><span class="dashicons dashicons-calendar-alt" style="margin-top: 3px;"></span> Add Booking Form</a>';
}
add_action('media_buttons', 'as_add_media_button');

function as_media_button_script() {
    ?>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('#insert-appointment-shortcode').click(function(e) {
            e.preventDefault();
            wp.media.editor.insert('[booking_widget]');
        });
    });
    </script>
    <?php
}
add_action('admin_footer', 'as_media_button_script');

// 3. Shortcode Handler
function as_render_booking_widget($atts) {
    // Get stored slug if attribute not provided
    $stored_slug = get_option('as_company_slug');
    
    $a = shortcode_atts(array(
        'slug' => $stored_slug, // Default to saved setting
        'theme' => 'light'
    ), $atts);

    if (empty($a['slug'])) {
        return '<div style="background:#fff4f4; border:1px solid #dc3232; padding:10px; border-radius:4px; color:#dc3232;">' .
               '<strong>Widget Error:</strong> No company slug found. Please verify your settings in Settings &gt; Appointment Widget.</div>';
    }

    $backend_url = 'http://localhost:5289'; // Your SaaS Backend URL
    $container_id = 'booking-widget-' . rand(1000, 9999);

    // Inline style wrapper to ensure it renders nicely in content
    $html = '<div class="appointment-widget-wrapper" style="width:100%; min-height:400px; margin: 20px 0;">';
    $html .= '<div id="' . esc_attr($container_id) . '" style="width:100%;"></div>';
    $html .= '<script>';
    $html .= '(function() {';
    $html .= '  var script = document.createElement("script");';
    $html .= '  script.src = "' . esc_url($backend_url) . '/widget/embed.js";';
    $html .= '  script.dataset.company = "' . esc_attr($a['slug']) . '";';
    $html .= '  script.dataset.container = "' . esc_attr($container_id) . '";';
    $html .= '  script.dataset.theme = "' . esc_attr($a['theme']) . '";';
    $html .= '  document.body.appendChild(script);';
    $html .= '})();';
    $html .= '</script>';
    $html .= '</div>';

    return $html;
}
add_shortcode('booking_widget', 'as_render_booking_widget');
